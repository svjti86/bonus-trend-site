import HeroImage from '../assets/images/hero-placeholder.png'

export { HeroImage }
